import React, { useState } from 'react';
import assets from '../assets/assets';

const Navbar = ({ theme, setTheme }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className='flex justify-between items-center px-4 sm:px-8 lg:px-16 xl:px-24 py-3 sticky top-0 z-50 backdrop-blur-xl font-medium bg-white/60 dark:bg-gray-900/70 shadow-md'>
      {/* Logo */}
      <div className='flex items-center gap-2'>
        <img
          src={theme === 'dark' ? assets['logo-dark'] : assets.logo}
          className='h-8 sm:h-10 object-contain'
          alt='Combo Square Logo'
        />
        <span className='text-xl sm:text-2xl font-bold tracking-tight text-primary dark:text-white'>
          Combo Square
        </span>
      </div>

      {/* Desktop Navigation Links */}
      <div className='hidden md:flex items-center gap-8 text-gray-700 dark:text-white text-base'>
        <a href="#home" className='font-medium tracking-wide hover:text-primary transition-colors'>
          Home
        </a>
        <a href="#services" className='font-medium tracking-wide hover:text-primary transition-colors'>
          Services
        </a>
        <a href="#our-work" className='font-medium tracking-wide hover:text-primary transition-colors'>
          Our Work
        </a>
        <a href="#contact-us" className='font-medium tracking-wide hover:text-primary transition-colors'>
          Contact Us
        </a>

        {/* Connect Button */}
        <a
          href="#contact-us"
          className='flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-full hover:scale-105 transition-transform text-base font-semibold tracking-wide'
        >
          Connect
          <img src={assets.arrow_icon} width={14} alt="Arrow Icon" />
        </a>
      </div>

      {/* Mobile Menu Button */}
      <button
        className='md:hidden flex flex-col justify-center items-center w-8 h-8 text-gray-700 dark:text-white'
        onClick={toggleMenu}
        aria-label="Toggle menu"
      >
        <span
          className={`bg-primary dark:bg-white block transition-all duration-300 ease-out h-0.5 w-5 rounded-sm ${isMenuOpen ? 'rotate-45 translate-y-1' : '-translate-y-0.5'}`}
        ></span>
        <span
          className={`bg-primary dark:bg-white block transition-all duration-300 ease-out h-0.5 w-5 rounded-sm my-0.5 ${isMenuOpen ? 'opacity-0' : 'opacity-100'}`}
        ></span>
        <span
          className={`bg-primary dark:bg-white block transition-all duration-300 ease-out h-0.5 w-5 rounded-sm ${isMenuOpen ? '-rotate-45 -translate-y-1' : 'translate-y-0.5'}`}
        ></span>
      </button>

      {/* Mobile Menu (Dropdown Style) */}
      <div
        className={`absolute top-full left-0 w-full bg-white dark:bg-gray-900 shadow-lg md:hidden transform transition-transform duration-300 ease-in-out origin-top ${
          isMenuOpen ? 'scale-y-100' : 'scale-y-0'
        }`}
      >
        <nav className="flex flex-col items-center px-4 py-6 space-y-6">
          <a
            href="#home"
            className="text-lg font-medium tracking-wide text-gray-700 dark:text-white hover:text-primary transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </a>
          <a
            href="#services"
            className="text-lg font-medium tracking-wide text-gray-700 dark:text-white hover:text-primary transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Services
          </a>
          <a
            href="#our-work"
            className="text-lg font-medium tracking-wide text-gray-700 dark:text-white hover:text-primary transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Our Work
          </a>
          <a
            href="#contact-us"
            className="text-lg font-medium tracking-wide text-gray-700 dark:text-white hover:text-primary transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact Us
          </a>

          {/* Connect Button */}
          <a
            href="#contact-us"
            className='flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-full mt-4 hover:scale-105 transition-transform text-lg font-semibold tracking-wide'
            onClick={() => setIsMenuOpen(false)}
          >
            Connect
            <img src={assets.arrow_icon} width={14} alt="Arrow Icon" />
          </a>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;
