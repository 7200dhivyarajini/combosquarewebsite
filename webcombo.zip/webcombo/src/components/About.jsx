import React, { useState, useEffect, useRef } from "react";
import { FiUsers, FiTarget, FiBook, FiCode, FiHeart, FiAward, FiArrowRight, FiCalendar, FiTrendingUp, FiPlay, FiPause, FiChevronDown } from "react-icons/fi";

const About = () => {
  const [countersVisible, setCountersVisible] = useState(false);
  const [teamHover, setTeamHover] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentQuote, setCurrentQuote] = useState(0);
  const [typedText, setTypedText] = useState("");
  const [visibleSections, setVisibleSections] = useState({});
  const [activeStory, setActiveStory] = useState(0);
  const sectionRef = useRef(null);
  const videoRef = useRef(null);

  // Quotes for carousel
  const quotes = [
    "Transforming ideas into digital excellence.",
    "Where creativity meets technology.",
    "Building brands that inspire and connect.",
    "Innovation driven by passion and purpose."
  ];

  // Story data for the Our Story section
  const storyData = [
    {
      title: "TAS Innovation Era",
      period: "2018",
      description: "Started as a small innovation lab focused on solving complex business problems with cutting-edge technology.",
      icon: <FiTarget className="text-cyan-400" />,
      color: "cyan"
    },
    {
      title: "Combo Square Evolution",
      period: "2019-2020",
      description: "Evolved into a full-service digital agency combining creativity, technology, and strategy.",
      icon: <FiCode className="text-purple-400" />,
      color: "purple"
    },
    {
      title: "Exponential Growth",
      period: "2021-Present",
      description: "Built long-term relationships with 50+ diverse clients across multiple industries worldwide.",
      icon: <FiUsers className="text-green-400" />,
      color: "green"
    }
  ];

  // Setup Intersection Observers for scroll animations
  useEffect(() => {
    const sectionObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections(prev => ({
              ...prev,
              [entry.target.id]: true
            }));
          }
        });
      },
      { threshold: 0.2 }
    );

    // Observe all sections with IDs
    document.querySelectorAll('section[id]').forEach((section) => {
      sectionObserver.observe(section);
    });

    return () => {
      document.querySelectorAll('section[id]').forEach((section) => {
        sectionObserver.unobserve(section);
      });
    };
  }, []);

  // Counter animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setCountersVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  // Typewriter effect for hero text
  useEffect(() => {
    const fullText = "We are a creative digital agency focused on elevating brands through innovative solutions and transformative experiences.";
    let currentIndex = 0;
    
    const typingInterval = setInterval(() => {
      if (currentIndex <= fullText.length) {
        setTypedText(fullText.slice(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(typingInterval);
      }
    }, 40);
    
    return () => clearInterval(typingInterval);
  }, []);

  // Quotes carousel animation
  useEffect(() => {
    const quoteInterval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length);
    }, 4000);
    
    return () => clearInterval(quoteInterval);
  }, []);

  // Handle video play/pause
  const handleVideoToggle = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  // Counter component
  const Counter = ({ end, suffix, label }) => {
    const [count, setCount] = useState(0);
    
    useEffect(() => {
      if (countersVisible) {
        let start = 0;
        const duration = 2000; // ms
        const increment = end / (duration / 20);
        
        const timer = setInterval(() => {
          start += increment;
          if (start >= end) {
            setCount(end);
            clearInterval(timer);
          } else {
            setCount(Math.ceil(start));
          }
        }, 20);
        
        return () => clearInterval(timer);
      }
    }, [countersVisible, end]);
    
    return (
      <div className="text-center p-6 bg-white bg-opacity-5 rounded-2xl backdrop-filter backdrop-blur-lg border border-white border-opacity-10">
        <div className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 mb-2">
          {count}{suffix}
        </div>
        <div className="text-gray-300 text-sm md:text-base">{label}</div>
      </div>
    );
  };

  // Timeline data
  const timelineData = [
    { 
      title: "Idea & Foundation", 
      year: "2018", 
      description: "Combo Square was founded with a vision to bridge the gap between academia and industry.",
      icon: <FiTarget className="text-cyan-400" />
    },
    { 
      title: "First Clients", 
      year: "2019", 
      description: "We delivered our first projects and established long-term partnerships.",
      icon: <FiUsers className="text-purple-400" />
    },
    { 
      title: "Expansion", 
      year: "2020", 
      description: "Expanded our services to include training programs and college collaborations.",
      icon: <FiTrendingUp className="text-cyan-400" />
    },
    { 
      title: "Growth", 
      year: "2021-Present", 
      description: "Serving 50+ clients and training 2000+ students across multiple colleges.",
      icon: <FiAward className="text-purple-400" />
    }
  ];

  // Team data
  const teamData = [
    {
      name: "Alex Johnson",
      role: "CEO & Founder",
      bio: "10+ years of experience in software development and digital transformation. Passionate about education technology.",
      avatar: "/api/placeholder/200/200"
    },
    {
      name: "Sarah Williams",
      role: "Creative Director",
      bio: "Award-winning designer with expertise in brand development and user experience design.",
      avatar: "/api/placeholder/200/200"
    },
    {
      name: "Michael Chen",
      role: "CTO",
      bio: "Technology strategist specializing in scalable architecture and innovative digital solutions.",
      avatar: "/api/placeholder/200/200"
    },
    {
      name: "Priya Patel",
      role: "Head of Training",
      bio: "Education specialist focused on bridging the skills gap between academia and industry requirements.",
      avatar: "/api/placeholder/200/200"
    }
  ];

  // Approach data
  const approachData = [
    {
      title: "Discover",
      description: "We begin by understanding your business goals, target audience, and market positioning.",
      icon: <FiTarget size={24} />
    },
    {
      title: "Strategy",
      description: "Our team develops a comprehensive strategy tailored to your specific needs and objectives.",
      icon: <FiTrendingUp size={24} />
    },
    {
      title: "Execute",
      description: "We bring ideas to life with agile development methodologies and continuous collaboration.",
      icon: <FiCode size={24} />
    },
    {
      title: "Grow",
      description: "We measure results and optimize strategies to ensure continuous growth and improvement.",
      icon: <FiAward size={24} />
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-purple-900 text-white overflow-hidden">
      {/* Hero Section */}
      <section id="hero" className="relative py-16 md:py-24 px-4 text-center">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className={`container mx-auto relative z-10 transition-all duration-1000 ${visibleSections.hero ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-4xl md:text-6xl font-bold mb-6">About Combo Square</h1>
          
          {/* Typewriter text */}
          <div className="h-24 md:h-20 flex items-center justify-center">
            <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto typing-container">
              {typedText}
              <span className="typing-cursor">|</span>
            </p>
          </div>
          
          {/* Quotes carousel */}
          <div className="mt-8 h-12 flex items-center justify-center">
            {quotes.map((quote, index) => (
              <div 
                key={index}
                className={`absolute transition-opacity duration-1000 ${index === currentQuote ? 'opacity-100' : 'opacity-0'}`}
              >
                <div className="bg-white bg-opacity-10 px-6 py-3 rounded-full backdrop-filter backdrop-blur-lg border border-white border-opacity-10">
                  <p className="text-cyan-200 font-medium">{quote}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Combo Square with Video */}
      <section id="about-video" className="py-16 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-12 max-w-6xl mx-auto">
            {/* Text Content */}
            <div className={`flex-1 transition-all duration-1000 delay-300 ${visibleSections['about-video'] ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">About Combo Square</h2>
              <p className="text-gray-300 mb-6">
                Combo Square is a forward-thinking digital agency that combines creative vision with technical 
                expertise to deliver exceptional digital experiences. Founded in 2018, we've grown into a 
                multidisciplinary team of designers, developers, and strategists passionate about helping 
                businesses thrive in the digital landscape.
              </p>
              <p className="text-gray-300 mb-6">
                Our unique approach blends innovation with practicality, ensuring that every solution we create 
                not only looks stunning but also delivers measurable results. We believe in building long-term 
                partnerships with our clients, working collaboratively to achieve their goals.
              </p>
              <div className="grid grid-cols-2 gap-4 mt-8">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-cyan-500 rounded-full flex items-center justify-center mr-3">
                    <FiTarget className="text-white" />
                  </div>
                  <span className="text-sm">Result-Oriented</span>
                </div>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                    <FiUsers className="text-white" />
                  </div>
                  <span className="text-sm">Client-Focused</span>
                </div>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-3">
                    <FiCode className="text-white" />
                  </div>
                  <span className="text-sm">Innovative Solutions</span>
                </div>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center mr-3">
                    <FiTrendingUp className="text-white" />
                  </div>
                  <span className="text-sm">Growth Mindset</span>
                </div>
              </div>
            </div>
            
            {/* Video Section */}
            <div className={`flex-1 relative transition-all duration-1000 delay-500 ${visibleSections['about-video'] ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <div className="bg-white bg-opacity-10 rounded-2xl overflow-hidden backdrop-filter backdrop-blur-lg border border-white border-opacity-10 p-1">
                <div className="relative aspect-video bg-black rounded-xl overflow-hidden">
                  
                  {/* Video Element */}
                  <video 
                    ref={videoRef}
                    className="w-full h-full object-cover"
                    poster="/placeholder-video-poster.jpg"
                    muted
                    loop
                  >
                    <source src="/assets/about-video.mp4" type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                  
                  {/* Custom Play/Pause Button Overlay */}
                  <div className={`absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 transition-opacity duration-300 ${isPlaying ? 'opacity-0 hover:opacity-100' : 'opacity-100'}`}>
                    <button 
                      className="w-16 h-16 md:w-20 md:h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center backdrop-filter backdrop-blur-lg hover:bg-opacity-30 transition-all duration-300"
                      onClick={handleVideoToggle}
                    >
                      {isPlaying ? (
                        <FiPause className="text-white text-xl md:text-2xl" />
                      ) : (
                        <FiPlay className="text-white text-xl md:text-2xl ml-1" />
                      )}
                    </button>
                  </div>
                  
                  {/* Animated elements */}
                  <div className="absolute top-4 right-4 w-8 h-8 bg-cyan-400 rounded-full animate-pulse"></div>
                  <div className="absolute bottom-4 left-4 w-6 h-6 bg-purple-400 rounded-full animate-bounce delay-1000"></div>
                  <div className="absolute top-4 left-4 w-4 h-4 bg-green-400 rounded-full animate-ping"></div>
                </div>
                
                <div className="p-4 text-center">
                  <p className="text-gray-300 text-sm">Watch our story</p>
                </div>
              </div>
              
              {/* Floating elements around video */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-cyan-400 rounded-full opacity-60 animate-float1"></div>
              <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-purple-400 rounded-full opacity-60 animate-float2"></div>
              <div className="absolute -top-6 -left-6 w-12 h-12 bg-green-400 rounded-full opacity-30 animate-float3"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story Section - Responsive Design */}
      <section id="our-story" className="py-12 md:py-20 px-4 relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 left-1/4 w-48 md:w-72 h-48 md:h-72 bg-cyan-400 rounded-full filter blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/3 right-1/4 w-64 md:w-96 h-64 md:h-96 bg-purple-500 rounded-full filter blur-3xl animate-ping-slow"></div>
        </div>
        
        <div className="container mx-auto relative z-10">
          <h2 className={`text-3xl md:text-5xl font-bold text-center mb-4 md:mb-6 transition-all duration-1000 ${visibleSections['our-story'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">Journey</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 text-center max-w-3xl mx-auto mb-12 md:mb-16 px-4">
            From humble beginnings to becoming a trusted digital partner for businesses worldwide
          </p>
          
          {/* Mobile Accordion View */}
          <div className="md:hidden space-y-4 mb-12">
            {storyData.map((story, index) => (
              <div 
                key={index} 
                className={`bg-white/5 rounded-xl backdrop-blur-lg border border-white/10 overflow-hidden transition-all duration-500 ${activeStory === index ? 'ring-2 ring-cyan-400' : ''}`}
              >
                <button 
                  className="w-full p-4 flex items-center justify-between text-left"
                  onClick={() => setActiveStory(activeStory === index ? -1 : index)}
                >
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full bg-${story.color}-500/20 flex items-center justify-center mr-3`}>
                      {story.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold">{story.title}</h3>
                      <p className="text-sm text-gray-300">{story.period}</p>
                    </div>
                  </div>
                  <FiChevronDown className={`transform transition-transform ${activeStory === index ? 'rotate-180' : ''}`} />
                </button>
                
                <div className={`overflow-hidden transition-all duration-500 ${activeStory === index ? 'max-h-40' : 'max-h-0'}`}>
                  <div className="p-4 pt-0 border-t border-white/10">
                    <p className="text-gray-300">{story.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Desktop Timeline View */}
            <div className="max-w-5xl mx-auto">
                     {/* TAS Innovation */}
                     <div className={`flex flex-col md:flex-row items-center mb-24 transition-all duration-1000 delay-150 ${visibleSections['our-story'] ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
                       <div className="md:w-2/5 md:pr-10 mb-8 md:mb-0 order-2 md:order-1 text-center md:text-right">
                         <h3 className="text-2xl md:text-3xl font-bold mb-4">TAS Innovation Era</h3>
                         <p className="text-gray-300 mb-4">
                           Started as a small innovation lab focused on solving complex business problems with cutting-edge technology.
                         </p>
                         <div className="inline-flex items-center text-cyan-400 font-semibold">
                           <span>2018</span>
                           <div className="w-12 h-px bg-cyan-400 mx-3"></div>
                           <FiTarget className="text-cyan-400" />
                         </div>
                       </div>
                       <div className="md:w-1/5 flex justify-center order-1 md:order-2 relative">
                         <div className="w-4 h-4 bg-cyan-400 rounded-full ring-8 ring-cyan-400/20 z-10"></div>
                         <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-cyan-400/10 rounded-full animate-ping-slow"></div>
                       </div>
                       <div className="md:w-2/5 order-3 hidden md:block"></div>
                     </div>
                     
                     {/* Combo Square Transformation */}
                     <div className={`flex flex-col md:flex-row items-center mb-24 transition-all duration-1000 delay-300 ${visibleSections['our-story'] ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
                       <div className="md:w-2/5 order-3 hidden md:block"></div>
                       <div className="md:w-1/5 flex justify-center order-1 md:order-2 relative">
                         <div className="w-4 h-4 bg-purple-400 rounded-full ring-8 ring-purple-400/20 z-10"></div>
                         <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-purple-400/10 rounded-full animate-ping-slow"></div>
                       </div>
                       <div className="md:w-2/5 md:pl-10 mb-8 md:mb-0 order-2 md:order-3 text-center md:text-left">
                         <h3 className="text-2xl md:text-3xl font-bold mb-4">Combo Square Evolution</h3>
                         <p className="text-gray-300 mb-4">
                           Evolved into a full-service digital agency combining creativity, technology, and strategy.
                         </p>
                         <div className="inline-flex items-center text-purple-400 font-semibold">
                           <FiCode className="text-purple-400" />
                           <div className="w-12 h-px bg-purple-400 mx-3"></div>
                           <span>2019-2020</span>
                         </div>
                       </div>
                     </div>
                     
                     {/* Growth Phase */}
                     <div className={`flex flex-col md:flex-row items-center transition-all duration-1000 delay-450 ${visibleSections['our-story'] ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
                       <div className="md:w-2/5 md:pr-10 mb-8 md:mb-0 order-2 md:order-1 text-center md:text-right">
                         <h3 className="text-2xl md:text-3xl font-bold mb-4">Exponential Growth</h3>
                         <p className="text-gray-300 mb-4">
                           Built long-term relationships with 50+ diverse clients across multiple industries worldwide.
                         </p>
                         <div className="inline-flex items-center text-green-400 font-semibold">
                           <span>2021-Present</span>
                           <div className="w-12 h-px bg-green-400 mx-3"></div>
                           <FiUsers className="text-green-400" />
                         </div>
                       </div>
                       <div className="md:w-1/5 flex justify-center order-1 md:order-2 relative">
                         <div className="w-4 h-4 bg-green-400 rounded-full ring-8 ring-green-400/20 z-10"></div>
                         <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-green-400/10 rounded-full animate-ping-slow"></div>
                         {/* Connecting line */}
                         <div className="absolute h-24 md:h-48 w-1 bg-gradient-to-b from-cyan-400 to-purple-400 to-green-400 -top-24 md:-top-48"></div>
                       </div>
                       <div className="md:w-2/5 order-3 hidden md:block"></div>
                     </div>
                   </div>

          {/* Floating metrics - Responsive grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mt-16 md:mt-32">
            <div className={`text-center p-6 md:p-8 bg-white/5 rounded-2xl backdrop-blur-lg border border-white/10 transform transition-all duration-1000 hover:-translate-y-2 ${visibleSections['our-story'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <div className="text-4xl md:text-5xl font-bold text-cyan-400 mb-3 md:mb-4">5+</div>
              <div className="text-lg md:text-xl font-semibold mb-2">Years of Excellence</div>
              <p className="text-gray-300 text-sm md:text-base">Delivering innovative solutions since 2018</p>
            </div>
            
            <div className={`text-center p-6 md:p-8 bg-white/5 rounded-2xl backdrop-blur-lg border border-white/10 transform transition-all duration-1000 delay-200 hover:-translate-y-2 ${visibleSections['our-story'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <div className="text-4xl md:text-5xl font-bold text-purple-400 mb-3 md:mb-4">50+</div>
              <div className="text-lg md:text-xl font-semibold mb-2">Global Clients</div>
              <p className="text-gray-300 text-sm md:text-base">Serving businesses across different industries</p>
            </div>
            
            <div className={`text-center p-6 md:p-8 bg-white/5 rounded-2xl backdrop-blur-lg border border-white/10 transform transition-all duration-1000 delay-400 hover:-translate-y-2 ${visibleSections['our-story'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
              <div className="text-4xl md:text-5xl font-bold text-green-400 mb-3 md:mb-4">200+</div>
              <div className="text-lg md:text-xl font-semibold mb-2">Projects Delivered</div>
              <p className="text-gray-300 text-sm md:text-base">Successfully completed digital transformations</p>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission Section */}
      <section id="vision-mission" className="py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div className={`text-center md:text-left transition-all duration-1000 ${visibleSections['vision-mission'] ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <div className="w-20 h-20 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center mx-auto md:mx-0 mb-6 animate-pulse">
                <FiTrendingUp size={32} />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Our Vision</h2>
              <p className="text-gray-300">
                To be the leading digital innovation partner for businesses seeking transformative growth 
                through creative technology solutions and exceptional user experiences.
              </p>
            </div>
            
            <div className={`text-center md:text-left transition-all duration-1000 delay-300 ${visibleSections['vision-mission'] ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto md:mx-0 mb-6 animate-bounce">
                <FiTarget size={32} />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Our Mission</h2>
              <p className="text-gray-300">
                To empower businesses with innovative digital solutions that drive growth, enhance brand presence, 
                and create meaningful connections with their audience through creativity and technology.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Stats Section */}
      <section id="impact-stats" ref={sectionRef} className="py-16 px-4 bg-white bg-opacity-5">
        <div className="container mx-auto">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-16 transition-all duration-1000 ${visibleSections['impact-stats'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>Our Impact</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 max-w-6xl mx-auto">
            <Counter end={50} suffix="+" label="Happy Clients" />
            <Counter end={200} suffix="+" label="Students Trained" />
            <Counter end={20} suffix="+" label="Colleges Collaborated" />
            <Counter end={100} suffix="+" label="Projects Delivered" />
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section id="timeline" className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-16 transition-all duration-1000 ${visibleSections.timeline ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>Our Journey</h2>
          
          <div className="relative max-w-4xl mx-auto">
            {/* Timeline line */}
            <div className="absolute left-2 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-cyan-500 to-purple-500 transform md:-translate-x-1/2"></div>
            
            {timelineData.map((item, index) => (
              <div key={index} className={`relative pl-10 md:pl-0 mb-12 md:mb-16 md:flex ${index % 2 === 0 ? 'md:flex-row-reverse' : ''} transition-all duration-1000 ${visibleSections.timeline ? 'opacity-100' : 'opacity-0'}`}>
                <div className="md:w-1/2 md:px-8 mb-4 md:mb-0">
                  <div className={`bg-white bg-opacity-10 p-6 rounded-2xl backdrop-filter backdrop-blur-lg border border-white border-opacity-10 ${index % 2 === 0 ? 'md:text-right' : ''}`}>
                    <div className="text-cyan-400 font-semibold">{item.year}</div>
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-300">{item.description}</p>
                  </div>
                </div>
                
                <div className="absolute left-0 md:left-1/2 top-2 w-6 h-6 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 border-4 border-blue-900 transform -translate-x-2 md:-translate-x-1/2 z-10 flex items-center justify-center">
                  {item.icon}
                </div>
                
                <div className="md:w-1/2 md:px-8"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="py-16 px-4 bg-white bg-opacity-5">
        <div className="container mx-auto">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-16 transition-all duration-1000 ${visibleSections.team ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>Leadership Team</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {teamData.map((member, index) => (
              <div 
                key={index} 
                className={`bg-white bg-opacity-10 rounded-2xl overflow-hidden backdrop-filter backdrop-blur-lg border border-white border-opacity-10 transition-all duration-300 ${teamHover === index ? 'transform -translate-y-2 bg-opacity-20' : ''} ${visibleSections.team ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${index * 100}ms` }}
                onMouseEnter={() => setTeamHover(index)}
                onMouseLeave={() => setTeamHover(null)}
              >
                <div className="h-48 bg-gradient-to-r from-cyan-500 to-purple-500 relative">
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-24 h-24 rounded-full bg-blue-900 border-4 border-white overflow-hidden">
                    <div className="w-full h-full bg-gray-700 flex items-center justify-center">
                      <FiUsers size={32} />
                    </div>
                  </div>
                </div>
                
                <div className="pt-12 pb-6 px-6 text-center">
                  <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                  <div className="text-cyan-400 mb-4">{member.role}</div>
                  <p className="text-gray-300 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section id="approach" className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-16 transition-all duration-1000 ${visibleSections.approach ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>Our Approach</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {approachData.map((step, index) => (
              <div key={index} className={`bg-white bg-opacity-10 p-6 rounded-2xl backdrop-filter backdrop-blur-lg border border-white border-opacity-10 text-center transform transition-all duration-500 hover:-translate-y-2 ${visibleSections.approach ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${index * 100}ms` }}>
                <div className="w-14 h-14 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-gray-300 text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CSR Section */}
      <section id="csr" className="py-16 px-4 bg-white bg-opacity-5">
        <div className="container mx-auto">
          <h2 className={`text-3xl md:text-4xl font-bold text-center mb-16 transition-all duration-1000 ${visibleSections.csr ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>Social Impact</h2>
          
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div className={`text-center md:text-left transition-all duration-1000 ${visibleSections.csr ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-teal-600 rounded-full flex items-center justify-center mx-auto md:mx-0 mb-6">
                <FiHeart size={32} />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Community Initiatives</h3>
              <p className="text-gray-300 mb-4">
                We believe in giving back to the community that supports us. Our team regularly volunteers 
                and contributes to local educational programs and environmental conservation efforts.
              </p>
              <ul className="text-gray-300 space-y-2 text-left">
                <li className="flex items-center">
                  <FiArrowRight className="text-cyan-400 mr-2" /> Annual scholarship programs for underprivileged students
                </li>
                <li className="flex items-center">
                  <FiArrowRight className="text-cyan-400 mr-2" /> Free workshops and training sessions for community development
                </li>
                <li className="flex items-center">
                  <FiArrowRight className="text-cyan-400 mr-2" /> Environmental sustainability initiatives and awareness campaigns
                </li>
              </ul>
            </div>
            
            <div className={`text-center md:text-left transition-all duration-1000 delay-300 ${visibleSections.csr ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto md:mx-0 mb-6">
                <FiBook size={32} />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Education Outreach</h3>
              <p className="text-gray-300 mb-4">
                We partner with educational institutions to bridge the gap between academia and industry, 
                preparing the next generation of digital professionals with practical skills and knowledge.
              </p>
              <ul className="text-gray-300 space-y-2 text-left">
                <li className="flex items-center">
                  <FiArrowRight className="text-purple-400 mr-2" /> Industry-academia collaboration programs
                </li>
                <li className="flex items-center">
                  <FiArrowRight className="text-purple-400 mr-2" /> Guest lectures and mentorship programs
                </li>
                <li className="flex items-center">
                  <FiArrowRight className="text-purple-400 mr-2" /> Curriculum development support for digital skills
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="cta" className="py-16 px-4 bg-gradient-to-r from-cyan-600 to-purple-600">
        <div className={`container mx-auto text-center transition-all duration-1000 ${visibleSections.cta ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to elevate your brand?</h2>
          <p className="text-xl text-white opacity-90 mb-8 max-w-3xl mx-auto">
            Let's collaborate to create something extraordinary that drives your business forward.
          </p>
          <button className="bg-white text-cyan-600 font-semibold py-3 px-8 rounded-full hover:bg-gray-100 transition-all duration-300">
            Get in Touch
          </button>
        </div>
      </section>

      <style jsx>{`
        .typing-cursor {
          animation: blink 1s infinite;
        }
        
        @keyframes blink {
          0%, 50% { opacity: 1; }
          51%, 100% { opacity: 0; }
        }
        
        @keyframes float1 {
          0%, 100% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-10px) translateX(5px); }
        }
        
        @keyframes float2 {
          0%, 100% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(10px) translateX(-5px); }
        }
        
        @keyframes float3 {
          0%, 100% { transform: translateY(0) translateX(0) scale(1); }
          50% { transform: translateY(-5px) translateX(-5px) scale(1.1); }
        }
        
        @keyframes ping-slow {
          0% {
            transform: scale(1);
            opacity: 1;
          }
          75%, 100% {
            transform: scale(2);
            opacity: 0;
          }
        }
        
        .animate-float1 {
          animation: float1 6s ease-in-out infinite;
        }
        
        .animate-float2 {
          animation: float2 7s ease-in-out infinite;
        }
        
        .animate-float3 {
          animation: float3 8s ease-in-out infinite;
        }
        
        .animate-ping-slow {
          animation: ping-slow 3s cubic-bezier(0, 0, 0.2, 1) infinite;
        }
      `}</style>
    </div>
  );
};

export default About;