import React, { useState, useEffect, useRef } from "react";
import { FiMenu, FiX, FiHome, FiServer, FiBriefcase, FiMail } from "react-icons/fi";
import assets from "../assets/assets";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [theme, setTheme] = useState("light");
  const [showLogo, setShowLogo] = useState(false);
  const [textRevealed, setTextRevealed] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [elementsVisible, setElementsVisible] = useState(Array(6).fill(false));
  const menuRef = useRef(null);

  useEffect(() => {
    // Text reveal animation
    const textTimer = setTimeout(() => setTextRevealed(true), 800);
    // Logo reveal after text
    const logoTimer = setTimeout(() => setShowLogo(true), 1800);
    
    // Animate navbar elements sequentially
    const elementTimers = [];
    for (let i = 0; i < elementsVisible.length; i++) {
      elementTimers.push(
        setTimeout(() => {
          setElementsVisible(prev => {
            const newState = [...prev];
            newState[i] = true;
            return newState;
          });
        }, 2000 + (i * 100)) // Stagger the animations
      );
    }
    
    // Handle scroll event
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    
    // Close menu when clicking outside
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    
    return () => {
      clearTimeout(textTimer);
      clearTimeout(logoTimer);
      elementTimers.forEach(timer => clearTimeout(timer));
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, []);

  const navLinks = [
    { name: "Home", path: "#home", icon: <FiHome size={18} /> },
    { name: "Services", path: "#services", icon: <FiServer size={18} /> },
    { name: "Our Work", path: "#our-work", icon: <FiBriefcase size={18} /> },
    { name: "Contact", path: "#contact", icon: <FiMail size={18} /> },
  ];

  return (
    <div className={`w-full flex justify-center fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'py-0 bg-white shadow-md' : 'py-4'}`}>
      <nav 
        ref={menuRef}
        className={`bg-white rounded-2xl shadow-xl px-4 md:px-6 py-2 md:py-3 w-[95%] md:w-[90%] max-w-2xl md:max-w-6xl transition-all duration-300 ${scrolled ? 'md:rounded-b-none md:shadow-lg' : ''}`}
      >
        <div className="flex items-center justify-between">
          {/* Logo + Animated Text */}
          <div className="flex items-center gap-2 md:gap-3 cursor-pointer">
            {showLogo && (
              <div className="relative">
                <img
                  src={theme === "dark" ? assets["logo-dark"] : assets.logo}
                  className="h-7 md:h-8 object-contain"
                  alt="Combo Square Logo"
                  style={{
                    animation: "logoReveal 1s cubic-bezier(0.68, -0.55, 0.27, 1.55) forwards, logoPulse 2s ease-in-out infinite 1s"
                  }}
                />
              </div>
            )}
            
            <a
              href="/"
              className="relative text-xl md:text-2xl font-bold text-gray-900 whitespace-nowrap overflow-hidden"
            >
              {/* Typewriter effect with gradient reveal */}
              <span 
                className={`inline-block bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent transition-all duration-1000 ${
                  textRevealed 
                    ? "max-w-full opacity-100" 
                    : "max-w-0 opacity-0"
                }`}
                style={{
                  transition: "max-width 1.5s cubic-bezier(0.785, 0.135, 0.15, 0.86), opacity 1s ease-out"
                }}
              >
                ComboSquare
              </span>
              
              {/* Animated cursor */}
              <span 
                className={`absolute top-0 right-0 h-full w-0.5 bg-purple-600 transition-opacity duration-500 ${
                  textRevealed ? "opacity-0" : "opacity-100"
                }`}
                style={{
                  animation: textRevealed ? "none" : "blink 1s infinite"
                }}
              ></span>
            </a>
          </div>

          {/* Desktop Menu with Animated Items */}
          <div className="hidden md:flex items-center space-x-6 lg:space-x-8">
            {navLinks.map((link, index) => (
              <a
                key={link.name}
                href={link.path}
                className={`text-gray-700 hover:text-purple-600 transition tracking-wide relative py-1 group ${
                  elementsVisible[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
                style={{
                  transition: 'opacity 0.5s ease, transform 0.5s ease',
                  transitionDelay: `${index * 0.1 + 0.2}s`
                }}
              >
                <span className="relative z-10 text-sm lg:text-base">{link.name}</span>
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-purple-600 transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
            
            {/* Animated CTA Button */}
            <a
              href="#contact"
              className={`ml-2 lg:ml-4 flex items-center gap-1 lg:gap-2 bg-gradient-to-r from-purple-600 to-purple-800 text-white px-3 lg:px-4 py-1.5 lg:py-2 rounded-full font-semibold hover:scale-105 transition-all duration-300 shadow-md shadow-purple-500/20 hover:shadow-purple-500/40 text-sm lg:text-base ${
                elementsVisible[4] ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
              }`}
              style={{
                transition: 'opacity 0.5s ease, transform 0.5s ease',
                transitionDelay: '0.6s'
              }}
            >
              Connect
              <img
                src={assets.arrow_icon}
                width={12}
                alt="Arrow Icon"
                className="transition-transform duration-300 hover:translate-x-1"
              />
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-purple-600 focus:outline-none transition-transform duration-300 p-2 rounded-full bg-gray-100 hover:bg-purple-100"
              aria-label="Toggle menu"
            >
              {isOpen ? <FiX size={24} /> : <FiMenu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu with Animated Items */}
        {isOpen && (
          <div className="md:hidden mt-3 bg-white rounded-xl shadow-lg p-4 space-y-2 animate-slideDown">
            {navLinks.map((link, index) => (
              <a
                key={link.name}
                href={link.path}
                className="flex items-center gap-3 text-gray-700 hover:text-purple-600 transition py-3 px-4 rounded-lg hover:bg-purple-50 animate-fadeIn"
                style={{ 
                  animationDelay: `${index * 0.1}s`,
                }}
                onClick={() => setIsOpen(false)}
              >
                <span className="text-purple-600">{link.icon}</span>
                <span className="font-medium">{link.name}</span>
              </a>
            ))}
            
            {/* CTA Button in mobile */}
            <a
              href="#contact"
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-purple-800 text-white px-4 py-3 rounded-full font-semibold transition-all duration-300 shadow-md shadow-purple-500/20 mt-2 animate-fadeIn"
              style={{ 
                animationDelay: '0.4s',
              }}
              onClick={() => setIsOpen(false)}
            >
              Connect Now
              <img src={assets.arrow_icon} width={14} alt="Arrow Icon" />
            </a>
          </div>
        )}
      </nav>
      
      {/* Animation styles */}
      <style jsx>{`
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
        
        @keyframes logoReveal {
          0% { 
            opacity: 0;
            transform: translateX(-10px) scale(0.8);
          }
          70% {
            transform: translateX(2px) scale(1.05);
          }
          100% { 
            opacity: 1;
            transform: translateX(0) scale(1);
          }
        }
        
        @keyframes logoPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.08); }
        }
        
        @keyframes slideDown {
          from { 
            opacity: 0;
            transform: translateY(-10px);
          }
          to { 
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes fadeIn {
          from { 
            opacity: 0;
            transform: translateY(10px);
          }
          to { 
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-slideDown {
          animation: slideDown 0.3s ease-out forwards;
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.5s forwards;
        }
        
        /* Improve touch targets for mobile */
        @media (max-width: 768px) {
          nav a, nav button {
            min-height: 44px;
            min-width: 44px;
            display: flex;
            align-items: center;
          }
        }
      `}</style>
    </div>
  );
}