import React, { useState, useEffect } from "react";
import { FiArrowRight, FiPlay } from "react-icons/fi";

const Home = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [loaded, setLoaded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Set loaded to true after component mounts to trigger animations
    setLoaded(true);
    
    // Check if device is mobile
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    
    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);
    
    // Handle mouse movement for 3D effect (desktop only)
    const handleMouseMove = (e) => {
      if (window.innerWidth >= 1024) { // Only apply 3D effect on desktop
        setMousePosition({ 
          x: (e.clientX / window.innerWidth - 0.5) * 2,
          y: (e.clientY / window.innerHeight - 0.5) * 2
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', checkIsMobile);
    };
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 lg:pt-0">
      {/* Background with overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-purple-900 opacity-95 z-0"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0 z-0 opacity-20">
        {[...Array(15)].map((_, i) => (
          <div 
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: `${Math.random() * 50 + 20}px`,
              height: `${Math.random() * 50 + 20}px`,
              opacity: Math.random() * 0.3 + 0.1,
              animation: `pulse ${Math.random() * 5 + 3}s infinite alternate`
            }}
          ></div>
        ))}
      </div>

      <div className="container mx-auto px-4 sm:px-6 relative z-10 py-12 lg:py-0">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
          {/* Text Content - Order changes on mobile */}
          <div className="flex-1 text-center lg:text-left order-2 lg:order-1">
            <h1 className={`text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-1000 ease-out ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}>
              We Elevate Your Brand by <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">Creativity</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-200 mb-8 lg:mb-10 max-w-2xl mx-auto lg:mx-0 transition-opacity duration-1000 delay-300">
              Transforming ideas into digital experiences that captivate your audience and drive growth for your business.
            </p>
            
            <div className={`flex flex-col sm:flex-row gap-4 justify-center lg:justify-start transition-all duration-1000 delay-500 ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}>
              <button className="bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold py-3 px-6 lg:py-4 lg:px-8 rounded-full flex items-center justify-center gap-2 hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300 text-sm lg:text-base">
                Get Started <FiArrowRight className="inline" />
              </button>
              
              <button className="bg-transparent border-2 border-white text-white font-semibold py-3 px-6 lg:py-4 lg:px-8 rounded-full flex items-center justify-center gap-2 hover:bg-white hover:text-purple-900 transition-all duration-300 text-sm lg:text-base">
                <FiPlay className="inline" /> Explore Services
              </button>
            </div>
          </div>
          
          {/* 3D Animated Banner - Order changes on mobile */}
          <div className={`flex-1 flex justify-center transition-all duration-1000 delay-300 order-1 lg:order-2 mb-8 lg:mb-0 ${
            loaded ? 'opacity-100' : 'opacity-0'
          }`}>
            <div 
              className="relative w-full max-w-xs sm:max-w-sm md:max-w-md"
              style={{
                transform: isMobile 
                  ? 'none' 
                  : `perspective(1000px) rotateX(${mousePosition.y * 5}deg) rotateY(${mousePosition.x * 5}deg)`,
                transition: 'transform 0.1s ease-out'
              }}
            >
              <div className="absolute -inset-2 lg:-inset-4 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-3xl blur-xl opacity-30 animate-pulse"></div>
              
              <div className="relative bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg rounded-2xl p-4 sm:p-6 md:p-8 border border-white border-opacity-20 shadow-2xl">
                <div className="grid grid-cols-2 gap-3 sm:gap-4">
                  {/* Card 1 */}
                  <div className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl p-3 sm:p-4 h-32 sm:h-40 flex flex-col justify-between transform hover:-translate-y-2 transition-transform duration-300">
                    <div className="text-white font-bold text-sm sm:text-base">Design</div>
                    <div className="h-6 w-6 sm:h-8 sm:w-8 bg-white rounded-full flex items-center justify-center ml-auto">
                      <FiArrowRight className="text-cyan-600 text-xs sm:text-sm" />
                    </div>
                  </div>
                  
                  {/* Card 2 */}
                  <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl p-3 sm:p-4 h-32 sm:h-40 flex flex-col justify-between transform hover:-translate-y-2 transition-transform duration-300">
                    <div className="text-white font-bold text-sm sm:text-base">Development</div>
                    <div className="h-6 w-6 sm:h-8 sm:w-8 bg-white rounded-full flex items-center justify-center ml-auto">
                      <FiArrowRight className="text-purple-600 text-xs sm:text-sm" />
                    </div>
                  </div>
                  
                  {/* Card 3 */}
                  <div className="bg-gradient-to-br from-green-500 to-teal-600 rounded-xl p-3 sm:p-4 h-32 sm:h-40 flex flex-col justify-between transform hover:-translate-y-2 transition-transform duration-300">
                    <div className="text-white font-bold text-sm sm:text-base">Marketing</div>
                    <div className="h-6 w-6 sm:h-8 sm:w-8 bg-white rounded-full flex items-center justify-center ml-auto">
                      <FiArrowRight className="text-green-600 text-xs sm:text-sm" />
                    </div>
                  </div>
                  
                  {/* Card 4 */}
                  <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-xl p-3 sm:p-4 h-32 sm:h-40 flex flex-col justify-between transform hover:-translate-y-2 transition-transform duration-300">
                    <div className="text-white font-bold text-sm sm:text-base">Strategy</div>
                    <div className="h-6 w-6 sm:h-8 sm:w-8 bg-white rounded-full flex items-center justify-center ml-auto">
                      <FiArrowRight className="text-orange-600 text-xs sm:text-sm" />
                    </div>
                  </div>
                </div>
                
                {/* Floating elements (hidden on mobile) */}
                {!isMobile && (
                  <>
                    <div className="absolute -top-2 -right-2 lg:-top-4 lg:-right-4 w-4 h-4 lg:w-8 lg:h-8 bg-cyan-400 rounded-full animate-bounce"></div>
                    <div className="absolute -bottom-2 -left-2 lg:-bottom-4 lg:-left-4 w-3 h-3 lg:w-6 lg:h-6 bg-purple-400 rounded-full animate-bounce delay-300"></div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator (hidden on mobile) */}
      {!isMobile && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
          <div className="animate-bounce flex flex-col items-center text-white">
            <span className="text-sm mb-2">Scroll Down</span>
            <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
              <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
            </div>
          </div>
        </div>
      )}

      {/* Animation styles */}
      <style jsx>{`
        @keyframes pulse {
          0% { transform: scale(1); opacity: 0.2; }
          100% { transform: scale(1.1); opacity: 0.3; }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </section>
  );
};

export default Home;